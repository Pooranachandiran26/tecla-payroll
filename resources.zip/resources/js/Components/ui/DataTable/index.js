export { default } from './DataTable';
